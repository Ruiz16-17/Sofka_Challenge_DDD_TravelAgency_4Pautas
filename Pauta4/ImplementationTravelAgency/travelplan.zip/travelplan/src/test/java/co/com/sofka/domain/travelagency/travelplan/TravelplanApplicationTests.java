package co.com.sofka.domain.travelagency.travelplan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelplanApplicationTests {

	@Test
	void contextLoads() {
	}

}
