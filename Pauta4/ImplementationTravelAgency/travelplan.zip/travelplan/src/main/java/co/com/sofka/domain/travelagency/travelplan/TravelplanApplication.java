package co.com.sofka.domain.travelagency.travelplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelplanApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelplanApplication.class, args);
	}

}
